public @interface FieldDescription {
    String value = "";
}
