import java.util.Arrays;

public class Main {

    public static void main(String[] args) {

        long[] longNumbers;

        System.out.println(Arrays.toString(longNumbers));
    }
}